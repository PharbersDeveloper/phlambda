# -*- coding: utf-8 -*-


class PhAWS(object):
    """
    AWS 工具集的子类
    """
