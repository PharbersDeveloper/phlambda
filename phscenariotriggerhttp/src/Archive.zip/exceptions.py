class ScenarioResourceError(Exception):
    pass


class ScenarioStackNotExistError(Exception):
    pass
