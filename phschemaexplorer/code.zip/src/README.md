git_commit_version = {git_commit_version}
